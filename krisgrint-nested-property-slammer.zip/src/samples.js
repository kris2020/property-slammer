module.exports = {
  "house1": {
      "address": "1 Benson Avenue",
      "price": 315000,
      "floor_area": 925
  },
  "house2": {
      "address": "57 Benson Avenue",
      "price": 276000,
      "floor_area": 957
  },
  "house3": {
      "address": "21 Benson Avenue",
      "price": 280000,
      "floor_area": 957
  },
  "house4": {
      "address": "56 Benson Avenue",
      "price": 300000,
      "floor_area": 1022
  },
  "house5": {
      "address": "52 Benson Avenue",
      "price": 287500,
      "floor_area": 925
  }
};
